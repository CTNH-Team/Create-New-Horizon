---
navigation:
  parent: crazyae2addons_index.md
  title: 切石机配方
  icon: minecraft:stonecutter
categories:
  - Crafting and Patterns
---

# P2P通道转换配方

为提升灵活性、简化操作，Crazy AE2 Addons为应用能源2（AE2）及其附属的**P2P通道**新增了用于自由转换通道类型的**切石机配方**。

---

## 工作原理

- 将P2P通道放入**切石机**。
- 界面中会显示所有可用通道变种的转换选项。
- 选择转换目标然后取出产物即可，无需工作台或其他材料。