---
navigation:
  parent: crazyae2addons_index.md
  title: 变量终端
  icon: crazyae2addons:variable_terminal
categories:
  - Monitoring and Automation
item_ids:
  - crazyae2addons:variable_terminal
---

# 变量终端

**变量终端**是一种简单的线缆子部件，可以查看、添加、删除**ME数据控制器**中的所有**数据变量**。

是调试和手动调整自动化逻辑的不二之选。

---

## 使用方法

1. **放置子部件**，放置到ME线缆上即可。
2. **右击**打开界面。
3. 可在其中：
   - **浏览**所有变量，有搜索和分页功能。
   - **删除**变量（点击旁边的“X”按钮）。
   - **新增**变量，需在顶部输入栏中输入。

- 新增变量需要提供名称和一个整数值。
- 变动会立即应用。